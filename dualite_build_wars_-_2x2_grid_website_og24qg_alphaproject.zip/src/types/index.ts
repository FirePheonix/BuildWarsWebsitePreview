export interface Project {
  id: number;
  name: string;
  url: string;
  description: string;
  category: string;
  tools?: string;
  image?: string;
}

export interface SheetResponse {
  sheet1: Project[];
}
