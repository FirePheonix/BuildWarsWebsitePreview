import { useState, useEffect } from 'react';
import { Project, SheetResponse } from '../types';

export const useProjects = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        console.log('Fetching data from Sheety API...');
        
        const url = 'https://api.sheety.co/d4bd5bfc74b79f01d2aa0ff23c52bdca/dualiteEvent/sheet1';
        const response = await fetch(url);
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Raw API Response:', data);
        console.log('Available keys in response:', Object.keys(data));
        
        // Check for different possible response formats
        let projectData: Project[] = [];
        
        if (data.sheet1) {
          console.log('Found data.sheet1:', data.sheet1);
          projectData = data.sheet1;
        } else if (data.sheet1S) {
          console.log('Found data.sheet1S:', data.sheet1S);
          projectData = data.sheet1S;
        } else if (Array.isArray(data)) {
          console.log('Data is array:', data);
          projectData = data;
        } else {
          console.log('Unknown data format, using first available array property');
          const firstArrayProp = Object.values(data).find(val => Array.isArray(val));
          projectData = firstArrayProp as Project[] || [];
        }
        
        console.log('Processed project data:', projectData);
        console.log('Number of projects found:', projectData.length);
        
        // Log first project structure if available
        if (projectData.length > 0) {
          console.log('First project structure:', projectData[0]);
          console.log('First project keys:', Object.keys(projectData[0]));
        }
        
        setProjects(projectData.slice(0, 4)); // Limit to 4 projects for 2x2 grid
        setError(null);
      } catch (err) {
        console.error('Error fetching projects:', err);
        setError(`Failed to load projects: ${err instanceof Error ? err.message : 'Unknown error'}`);
        
        // Fallback data for demonstration
        setProjects([
          {
            id: 1,
            name: 'Sample Project 1',
            url: 'https://example.com',
            description: 'A beautiful web application',
            category: 'Web App',
            tools: 'React, TypeScript, Tailwind CSS'
          },
          {
            id: 2,
            name: 'Sample Game',
            url: 'https://example.com',
            description: 'An interactive game experience',
            category: 'Game',
            tools: 'JavaScript, Canvas API, WebGL'
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchProjects();
  }, []);

  return { projects, loading, error };
};
