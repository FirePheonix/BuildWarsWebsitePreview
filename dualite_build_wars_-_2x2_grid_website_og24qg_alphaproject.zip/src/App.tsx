import React from 'react';
import { GameProjectCard } from './components/GameProjectCard';
import { GameLoadingCard } from './components/GameLoadingCard';
import { ProtectedRoute } from './components/ProtectedRoute';
import { GameHeader } from './components/GameHeader';
import { WebsiteStatus } from './components/WebsiteStatus';
import { AgentActivity } from './components/AgentActivity';
import { FeedbackList } from './components/FeedbackList';
import { useProjects } from './hooks/useProjects';
import { motion } from 'framer-motion';

function AppContent() {
  const { projects, loading, error } = useProjects();

  return (
    <div className="min-h-screen bg-pitch-black text-pitch-white relative overflow-hidden flex flex-col">
      {/* Background Effects */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ y: -100, x: Math.random() * window.innerWidth }}
            animate={{ y: window.innerHeight + 100 }}
            transition={{
              duration: Math.random() * 15 + 10,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
            className="absolute text-terminal-green font-mono text-xs"
          >
            {Math.random().toString(36).substring(2, 12)}
          </motion.div>
        ))}
      </div>

      {/* Header */}
      <GameHeader />

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 flex-grow">
        {/* Error Alert */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-terminal-red bg-opacity-20 border border-terminal-red rounded-lg p-4 mb-8"
          >
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-terminal-red rounded-full animate-pulse"></div>
              <span className="font-mono text-terminal-red font-bold text-sm">SYSTEM_ERROR:</span>
            </div>
            <p className="font-mono text-terminal-red text-sm mt-1">{error}</p>
          </motion.div>
        )}

        {/* Website Grid */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 bg-terminal-green rounded-full animate-pulse"></div>
              <h2 className="font-mono text-terminal-green font-bold text-lg tracking-wide">
                ACTIVE WEBSITES
              </h2>
              <div className="flex-1 h-px bg-terminal-green opacity-30"></div>
              <span className="font-mono text-terminal-green text-sm">
                {loading ? 'LOADING' : `${projects.length}/4 DEPLOYED`}
              </span>
            </div>
          </motion.div>

          {/* 2x2 Website Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {loading ? (
              // Loading state
              Array.from({ length: 4 }).map((_, index) => (
                <GameLoadingCard key={index} index={index} />
              ))
            ) : (
              // Project cards
              projects.slice(0, 4).map((project, index) => (
                <GameProjectCard key={project.id || index} project={project} index={index} />
              ))
            )}
            
            {/* Fill empty slots if less than 4 projects */}
            {!loading && projects.length < 4 && 
              Array.from({ length: 4 - projects.length }).map((_, index) => (
                <motion.div 
                  key={`empty-${index}`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: (projects.length + index) * 0.1 }}
                  className="bg-console-bg border border-console-border rounded-lg p-6 flex flex-col items-center justify-center h-80 group hover:border-terminal-blue transition-all duration-300"
                >
                  <div className="text-center">
                    <div className="w-12 h-12 border-2 border-gray-700 border-dashed rounded-lg mb-4 mx-auto flex items-center justify-center group-hover:border-terminal-blue transition-colors">
                      <div className="w-4 h-4 bg-gray-700 rounded-full group-hover:bg-terminal-blue transition-colors"></div>
                    </div>
                    <p className="font-mono text-gray-500 text-sm text-center group-hover:text-terminal-blue transition-colors">
                      WEBSITE SLOT<br/>AVAILABLE
                    </p>
                    <div className="mt-2 text-xs font-mono text-gray-600">
                      AWAITING_DEPLOYMENT
                    </div>
                  </div>
                </motion.div>
              ))
            }
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-console-border bg-console-bg py-8 px-6 mt-12">
        <div className="container mx-auto">
          {/* New detailed footer content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <WebsiteStatus projectCount={projects.length} loading={loading} />
            <AgentActivity projects={projects} />
            <FeedbackList />
          </div>

          {/* Original footer content */}
          <div className="border-t border-console-border pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 bg-terminal-green rounded-full animate-pulse"></div>
                <span className="font-mono text-terminal-green text-sm">
                  DUALITE_ALPHA_v2.1.0
                </span>
              </div>
              <div className="font-mono text-gray-500 text-xs">
                SYSTEM_STATUS: OPERATIONAL | UPTIME: 99.9%
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <ProtectedRoute>
      <AppContent />
    </ProtectedRoute>
  );
}

export default App;
